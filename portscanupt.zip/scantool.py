import platform
import subprocess
import ipaddress
from scapy.all import arping

def ping_ip(ip):
    """Pings an IP. Returns True if alive."""
    param = '-n' if platform.system().lower()=='windows' else '-c'
    command = ['ping', param, '1', ip]
    try:
        return subprocess.run(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0
    except Exception:
        return False

def arp_scan(subnet):
    """Uses scapy to perform an ARP scan. Returns set of alive IPs."""
    answered, unanswered = arping(subnet, verbose=0)
    return set([r.psrc for s, r in answered])

def scan_subnet(subnet):
    """Combines ping and ARP scans, removes false positives with progress updates."""
    net = ipaddress.ip_network(subnet, strict=False)
    
    hosts = list(net.hosts())
    total_hosts = len(hosts)
    ping_alive = set()

    print("Starting Ping scan...")
    for i, ip in enumerate(hosts, start=1):
        if ping_ip(str(ip)):
            ping_alive.add(ip)
        # Print progress percentage
        percent = (i / total_hosts) * 100
        print(f"Ping scan progress: {percent:.2f}% ({i}/{total_hosts})", end='\r')

    print("\nStarting ARP scan...")
    arp_alive = arp_scan(subnet)
    
    both_alive = ping_alive & arp_alive  # Only IPs responding to both
    segment_count = total_hosts  # Usable hosts count (excluding network and broadcast)

    return {
        'ping_alive': ping_alive,
        'arp_alive': arp_alive,
        'both_alive': both_alive,
        'segment_count': segment_count
    }

# Example usage
subnet = '192.168.100.0/24'
results = scan_subnet(subnet)

print("\n1. Alive by ping:", sorted(str(ip) for ip in results['ping_alive']))
print("2. Alive by ARP:", sorted(results['arp_alive']))
print("3. Alive by both (filtered):", sorted(str(ip) for ip in results['both_alive']))
print("4. Segment count:", results['segment_count'])
